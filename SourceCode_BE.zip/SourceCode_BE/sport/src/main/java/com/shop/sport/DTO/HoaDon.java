package com.shop.sport.DTO;

public interface HoaDon {
    long getid_Order();
    String getproduct_name();
    long getquantity();
    float getprice();
    String getshipping_adress();
    String getname_reciver();
    String getsdt(); // số điện thoại người nhận hàng


}
