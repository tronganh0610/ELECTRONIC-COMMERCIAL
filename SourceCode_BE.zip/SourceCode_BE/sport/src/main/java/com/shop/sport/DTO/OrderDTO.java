package com.shop.sport.DTO;

public interface OrderDTO {
long getid_order_status();
    long getid_order();
    String getimage_url();
    String getid_product();
    String getproduct_name();
    String getquantity();
    String getprice();
}
