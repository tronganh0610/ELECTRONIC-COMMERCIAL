package com.shop.sport.Utils;

public enum MethodPayMent {
    SHIPCODE, BANKING, VISA,MOMO
}
