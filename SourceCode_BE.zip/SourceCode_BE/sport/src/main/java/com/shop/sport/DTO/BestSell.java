package com.shop.sport.DTO;

public interface BestSell {

  String  getproduct_name();
  long getquantity();

  float getprice();
}
