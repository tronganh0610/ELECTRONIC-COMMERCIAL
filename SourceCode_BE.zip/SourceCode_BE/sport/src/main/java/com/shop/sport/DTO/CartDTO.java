package com.shop.sport.DTO;

public interface CartDTO {
    long getid();
    long getquantity();
    String getimage_url();
    float getprice_total();
    String getproduct_name();
    long getproduct_id();
}
