package com.example.appsportshop.zalo.Constant;

public class AppInfo {
    public static final int APP_ID = 2553;
    public static final String MAC_KEY = "PcY4iZIKFCIdgZvA6ueMcMHHUbRLYjPL";
    public static final String URL_CREATE_ORDER = "https://sb-openapi.zalopay.vn/v2/create";
}
