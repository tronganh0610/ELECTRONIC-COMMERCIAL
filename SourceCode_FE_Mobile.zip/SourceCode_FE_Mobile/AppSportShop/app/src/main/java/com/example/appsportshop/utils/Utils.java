package com.example.appsportshop.utils;

public class Utils {
//    public  static final String BASE_URL="http://192.168.0.103:8080/api/v1/";
            //    public  static final String BASE_URL="http://127.0.0.1:8080/api/v1/";
public  static final String BASE_URL="http://192.168.1.85:8080/api/v1/";
  //  public  static final String BASE_URL="http://172.20.10.5:8080/api/v1/";


}

